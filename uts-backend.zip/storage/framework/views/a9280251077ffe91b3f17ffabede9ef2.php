<?php $__env->startSection('content'); ?>
    <section class="grid grid-cols-2 p-5">
        <div class="col-span-2">
            <h3 class="text-[36px]  text-center font-bold">Produk Kami</h3>
        </div>
        <div class="col-span-2 mx-auto">
            <div class="grid grid-cols-2 gap-5">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="rounded bg-white shadow-md w-[400px]">
                    <div class="divide-y">
                        <div class="relative">
                            <img src="<?php echo e(asset($data->photo)); ?>" class="rounded-t" alt="">
                        </div>
                        <div class="p-3">
                            <h1 class="font-bold text-[24px] "><?php echo e($data->title); ?></h1>
                        </div>
                        <p class="p-3">
                            <?php echo e($data->description); ?>

                        </p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="rounded bg-white shadow-md w-[400px]">
                    <div class="divide-y">
                        <div class="relative">
                            
                        </div>
                        <div class="p-3">
                            <h1 class="font-bold text-[24px] text-center">Coming Soon</h1>
                        </div>
                        <p class="p-3">
                            Ingin membuat Website baru? silahkan pilih <i>Order Now</i>
                            <br>
                        </p>
                    </div>
                    <div class="flex justify-center ">
                        <button
                            class="transition rounded px-3 py-1 outline outline-1 outline-green-400 hover:shadow-lg text-green-600">Order
                            Now</button>
                            
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\AffansyahProject\UTS\uts-backend\uts-backend\resources\views/products.blade.php ENDPATH**/ ?>